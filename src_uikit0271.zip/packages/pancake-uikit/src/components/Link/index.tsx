export { default as Link } from "./Link";
export { default as LinkExternal } from "./LinkExternal";
export type { LinkProps } from "./types";
