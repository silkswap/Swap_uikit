export { default as Skeleton } from "./Skeleton";
export type { SkeletonProps } from "./types";
